SMART ROPEWALK - SIMULADOR WEB
Paquete de referencia: firmware 3.66
Idioma: espanol

REQUISITOS

- Una Smart Ropewalk con firmware compatible con el Simulador Web.
- La maquina y el ordenador conectados a la misma red local.
- Un navegador moderno. Verificado en Windows con Microsoft Edge.
  Los archivos son independientes del sistema operativo; los navegadores
  en macOS todavia no se han verificado.

PRIMER USO

1. Extraer todo el ZIP en una carpeta del ordenador.
2. Mantener juntos index.html, styles.css, protocol.js, simulator.js
   y los archivos readme.
3. Encender Smart Ropewalk y conectarla al Wi-Fi.
4. Consultar la direccion IP de la maquina en la informacion Wi-Fi del display.
5. Abrir index.html en el navegador.
6. Introducir la IP en "Display address" y pulsar "Connect".
7. Utilizar los controles con el raton o mediante la pantalla tactil,
   igual que en la maquina. Arrastrar dentro de las listas para desplazarse;
   las flechas para cambiar de pagina siguen disponibles.

No se necesita instalacion ni un servidor Web local. Si el navegador solicita
permiso para acceder a los dispositivos de la red local, permitirlo a la pagina.

FUNCIONAMIENTO

El Simulador Web muestra la pantalla generada por el firmware de la maquina.
Paginas, menus, teclados, contadores y ventanas emergentes proceden del display.
La version del firmware aparece debajo de la pantalla. Las pantallas siguen
el idioma elegido en la maquina; los controles externos del panel son ingleses.

Los clics y los toques llegan al mismo gestor tactil de la maquina.
El firmware controla los motores, calculos, objetivos y ciclo automatico.
El navegador no simula movimientos ni evita la activacion: en modo demo,
los comandos de motor permanecen deshabilitados.

Es un panel remoto, no un simulador sin conexion. La maquina debe permanecer
encendida y conectada a la red.

ACTUALIZACION DE PANTALLA

El intervalo inicial es de 2 segundos; se puede elegir entre 1, 2 y 5 segundos.
La pantalla tambien se actualiza despues de los toques. Los cambios realizados
en el display fisico aparecen en el navegador en la siguiente actualizacion.

Despues de la primera imagen se transfieren, cuando es posible, solo los
pixeles modificados. Las solicitudes se suspenden si la pestana esta oculta.
No se guardan imagenes en la microSD. Las animaciones y contadores Web se
muestrean al intervalo seleccionado, no al ritmo de refresco del display fisico.

IMPORTANTE

Cerrar el navegador, pulsar "Disconnect" o perder el Wi-Fi NO detiene los
motores. La maquina continua segun el firmware y los objetivos configurados.
Si se pierde la conexion Web, utilizar el display fisico para detenerla.
Los toques no se reintentan automaticamente tras un error de conexion.

SOLUCION DE PROBLEMAS

- Sin conexion: comprobar IP, Wi-Fi y que ambos equipos esten en la misma red
  local. Las redes para invitados pueden aislar los dispositivos.
- Firmware no compatible: instalar una version con Simulador Web. El numero
  de version por si solo no distingue las compilaciones de desarrollo anteriores.
- Carga de maniobras: las operaciones de base de datos pueden retrasar la imagen.
  Esperar a que terminen sin pulsar repetidamente el mismo control.
- Interfaz antigua: abrir index.html desde la carpeta extraida y actualizar
  la pagina, ignorando la cache del navegador si es necesario.
- Mantener todos los archivos juntos; no abrir index.html dentro del ZIP.

El panel sigue automaticamente las paginas del firmware instalado mientras
el protocolo sea compatible. Utilizar el paquete Simulador Web distribuido
con la correspondiente version del firmware.
