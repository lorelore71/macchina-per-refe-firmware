/* Protocollo SRW1. La versione e tutte le pagine provengono dal firmware. */
(function (root) {
  "use strict";
  function decodeFrame(buffer, previous) {
    const bytes = new Uint8Array(buffer);
    if (bytes.length < 16 || String.fromCharCode(...bytes.subarray(0, 4)) !== "SRW1") throw new Error("Unsupported screen format");
    const header = new DataView(buffer);
    const width = header.getUint16(4, true);
    const height = header.getUint16(6, true);
    if (width !== 480 || height !== 320) throw new Error("Unsupported screen dimensions");
    const view = header.getUint32(8, true);
    const versionLength = bytes[12];
    let offset = 16 + versionLength;
    if (offset > bytes.length || (bytes.length - offset) % 3) throw new Error("Incomplete screen data");
    const version = new TextDecoder().decode(bytes.subarray(16, offset));
    const delta = bytes[13] === 1;
    if (bytes[13] > 1 || (delta && (!previous || previous.version !== version || previous.view !== view))) throw new Error("A full screen refresh is required");
    const rgba = delta ? new Uint8ClampedArray(previous.rgba) : new Uint8ClampedArray(width * height * 4);
    let pixel = 0;
    while (offset < bytes.length) {
      const run = bytes[offset++];
      const color = bytes[offset++] | (bytes[offset++] << 8);
      if (run === 0 && delta && color > 0 && pixel + color <= width * height) { pixel += color; continue; }
      if (run === 0 || pixel + run > width * height) throw new Error("Invalid screen data");
      const r = (color >> 11) & 31, g = (color >> 5) & 63, b = color & 31;
      for (let i = 0; i < run; i++, pixel++) {
        const p = pixel * 4;
        rgba[p] = (r << 3) | (r >> 2);
        rgba[p + 1] = (g << 2) | (g >> 4);
        rgba[p + 2] = (b << 3) | (b >> 2);
        rgba[p + 3] = 255;
      }
    }
    if (pixel !== width * height) throw new Error("Incomplete screen data");
    return { width, height, view, version, rgba, sequence: header.getUint16(14, true) };
  }
  function coordinates(clientX, clientY, rect) {
    return {
      x: Math.max(0, Math.min(479, Math.floor((clientX - rect.left) * 480 / rect.width))),
      y: Math.max(0, Math.min(319, Math.floor((clientY - rect.top) * 320 / rect.height))),
    };
  }
  function baseUrl(value) {
    const raw = value.trim();
    if (!raw) throw new Error("Enter the display IP address");
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`);
    if (!/^https?:$/.test(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== "/") throw new Error("Enter only the display address, without a path");
    return url.origin;
  }
  const api = { decodeFrame, coordinates, baseUrl };
  root.SmartRopewalkProtocol = api;
  if (typeof module !== "undefined") module.exports = api;
})(globalThis);
