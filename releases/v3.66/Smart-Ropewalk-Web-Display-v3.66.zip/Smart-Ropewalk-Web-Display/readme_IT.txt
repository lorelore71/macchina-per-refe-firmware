SMART ROPEWALK - SIMULATORE WEB
Pacchetto di riferimento: firmware 3.66
Lingua: italiano

REQUISITI

- Una Smart Ropewalk con firmware che supporta il Simulatore Web.
- Macchina e computer collegati alla stessa rete locale.
- Un browser moderno. Verificato su Windows con Microsoft Edge.
  I file sono indipendenti dal sistema operativo; i browser su macOS non sono
  ancora stati verificati.

PRIMO UTILIZZO

1. Estrarre tutto lo ZIP in una cartella del computer.
2. Mantenere insieme i file index.html, styles.css, protocol.js,
   simulator.js e i file readme.
3. Accendere Smart Ropewalk e collegarla al Wi-Fi.
4. Leggere l'indirizzo IP della macchina nelle informazioni Wi-Fi del display.
5. Aprire index.html nel browser.
6. Inserire l'IP nel campo "Display address" e premere "Connect".
7. Usare i comandi visualizzati con il mouse o il touch, come sul display.
   Trascinare il dito o il mouse nelle liste per scorrerle; restano disponibili
   anche le frecce per cambiare pagina.

Non occorrono installazioni o un server Web locale. Se il browser chiede il
permesso di accedere ai dispositivi della rete locale, consentirlo alla pagina.

FUNZIONAMENTO

Il Simulatore Web mostra la schermata effettivamente generata dal firmware.
Pagine, menu, tastiere, contatori e popup provengono tutti dal display.
La versione firmware compare sotto lo schermo. Le schermate seguono la lingua
scelta sulla macchina; i comandi esterni del pannello Web sono in inglese.

I clic e i tocchi entrano nello stesso gestore touch della macchina.
Il firmware controlla motori, calcoli, target e ciclo automatico.
Il browser non simula movimenti e non aggira l'attivazione: in demo mode
i comandi motore restano disabilitati.

Si tratta di un pannello remoto, non di un simulatore offline. La macchina
deve restare accesa e connessa alla rete.

AGGIORNAMENTO DELLO SCHERMO

L'intervallo iniziale e' di 2 secondi, selezionabile fra 1, 2 e 5 secondi.
Lo schermo si aggiorna anche dopo i tocchi. Le modifiche eseguite sul display
fisico compaiono nel browser al successivo aggiornamento.

Dopo la prima immagine vengono trasferiti, quando possibile, solo i pixel
cambiati. Le richieste si sospendono quando la scheda browser e' nascosta.
Nessuna immagine viene salvata sulla microSD. Animazioni e contatori Web sono
campionati all'intervallo selezionato: non hanno il refresh del display fisico.

IMPORTANTE

Chiudere il browser, premere "Disconnect" o perdere il Wi-Fi NON arresta
i motori. La macchina prosegue secondo il firmware e i target impostati.
In caso di perdita del collegamento Web, usare il touch fisico per fermarla.
I tocchi non vengono ritentati automaticamente dopo un errore di connessione.

RISOLUZIONE DEI PROBLEMI

- Connessione assente: verificare IP, Wi-Fi e appartenenza alla stessa rete
  locale. Le reti ospiti possono impedire il collegamento fra dispositivi.
- Firmware non supportato: installare una versione con Simulatore Web.
  Il solo numero versione non distingue le precedenti compilazioni di sviluppo.
- Caricamento manovre: le operazioni sul database possono ritardare lo schermo.
  Attendere il completamento senza premere ripetutamente lo stesso comando.
- Interfaccia vecchia: riaprire index.html dalla cartella estratta e ricaricare
  la pagina, ignorando la cache del browser se necessario.
- Tenere insieme tutti i file; non aprire index.html direttamente dentro lo ZIP.

Il pannello segue automaticamente le pagine del firmware installato finche'
il protocollo resta compatibile. Utilizzare il pacchetto Simulatore Web
distribuito insieme alla propria release firmware.
