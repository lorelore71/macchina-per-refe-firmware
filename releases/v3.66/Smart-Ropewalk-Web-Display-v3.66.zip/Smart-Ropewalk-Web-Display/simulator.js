/* Replica live LVGL: il firmware genera pagine e valori; il browser gestisce
   soltanto trasporto, pixel e coordinate del touch, senza simulare i motori. */
(function () {
  "use strict";
  const protocol = globalThis.SmartRopewalkProtocol;
  const $ = (id) => document.getElementById(id);
  const canvas = $("screen");
  const context = canvas.getContext("2d", { alpha: false });
  let endpoint = "", session = 0, connected = false, ready = false, busy = false;
  let timer, keepAlive, view = 0, queue = [], pointer = null;
  let frameDue = true, failures = 0, minRefresh = 1000, lastFrame = 0;
  let previousFrame = null;
  try { $("host").value = localStorage.getItem("smart-ropewalk-display-host") || localStorage.getItem("refe-esp32-host") || "192.168.178.144"; }
  catch { $("host").value = "192.168.178.144"; }

  function setState(message) { $("connectionState").textContent = message; }
  function showError(message) { $("error").textContent = message; $("error").hidden = !message; }
  function setReady(value) { ready = value; canvas.setAttribute("aria-disabled", String(!value)); }
  setReady(false);

  async function request(path, options = {}) {
    const controller = new AbortController();
    // La lettura della classe Steel puo' occupare il loop del firmware per
    // diversi secondi. Una sola lettura resta in attesa, senza richieste extra.
    const timeout = setTimeout(() => controller.abort(), path.startsWith("/web/frame") ? 45000 : 6000);
    try {
      const response = await fetch(endpoint + path, { ...options, cache: "no-store", signal: controller.signal });
      if (!response.ok) throw new Error(response.status === 404 ?
        "The installed firmware does not support Web Display. Upload the updated firmware via USB." :
        `The display returned HTTP ${response.status}`);
      // Anche il corpo deve arrivare prima del timeout, non solo gli header.
      return options.json ? await response.json() : options.text ? await response.text() : await response.arrayBuffer();
    } catch (error) {
      if (error.name === "AbortError") throw new Error("The display is not responding. Check Wi-Fi and the IP address");
      throw error;
    } finally { clearTimeout(timeout); }
  }

  function schedule(delay = 0) {
    clearTimeout(timer);
    if (connected) timer = setTimeout(pump, delay);
  }
  function interval() { return Math.max(Number($("refresh").value), minRefresh); }

  // Un trasferimento alla volta, precedenza al touch e pausa con tab nascosta.
  async function pump() {
    if (busy || !connected) return;
    const generation = session;
    busy = true;
    let next = 30;
    try {
      if (queue.length) {
        const sample = queue.shift();
        const body = new URLSearchParams({ x: sample.x, y: sample.y, pressed: sample.pressed ? "1" : "0", view: sample.view });
        await request("/web/input", { method: "POST", body, text: true });
        if (generation !== session) return;
        frameDue = true;
        next = queue.length ? 0 : 100;
      } else if (!document.hidden && !pointer && (frameDue || performance.now() - lastFrame >= interval())) {
        const started = performance.now();
        const suffix = previousFrame ? `?base=${previousFrame.sequence}` : "";
        const frame = protocol.decodeFrame(await request("/web/frame" + suffix), previousFrame);
        if (generation !== session) return;
        context.putImageData(new ImageData(frame.rgba, frame.width, frame.height), 0, 0);
        view = frame.view;
        previousFrame = frame;
        $("version").textContent = `Firmware: ${frame.version}`;
        document.title = `Smart Ropewalk ${frame.version} - Web Display`;
        $("placeholder").hidden = true;
        frameDue = false;
        lastFrame = performance.now();
        // Se il trasferimento e' lento riduce automaticamente il carico.
        minRefresh = Math.max(1000, Math.min(5000, (lastFrame - started) * 3));
        setReady(true);
        setState("Connected");
        next = interval();
      } else next = pointer ? 60 : interval();
      failures = 0;
      showError("");
    } catch (error) {
      if (generation !== session) return;
      failures++;
      // Mai ritentare un tocco: potrebbe duplicare START o un carattere.
      queue = [];
      pointer = null;
      clearInterval(keepAlive);
      setReady(false);
      setState("Connection lost");
      showError(`${error.message}. Touch commands are not retried automatically.`);
      frameDue = true;
      previousFrame = null;
      next = Math.min(10000, failures * 2000);
    } finally {
      busy = false;
      if (generation === session) schedule(queue.length ? 0 : next);
    }
  }

  async function connect(event) {
    event?.preventDefault();
    if (busy) return;
    disconnect();
    const generation = session;
    try {
      endpoint = protocol.baseUrl($("host").value);
      setState("Connecting...");
      $("connect").disabled = true;
      const info = await request("/web/ui", { json: true });
      if (generation !== session) return;
      if (info.protocol !== 1 || info.width !== 480 || info.height !== 320 || !info.inputReady) throw new Error("Web Display is not compatible with the installed firmware");
      try { localStorage.setItem("smart-ropewalk-display-host", endpoint); } catch { /* Storage facoltativo. */ }
      connected = true;
      document.body.dataset.connected = "true";
      $("host").disabled = true;
      $("disconnect").disabled = false;
      $("refreshNow").disabled = false;
      frameDue = true;
      showError("");
      schedule();
    } catch (error) {
      if (generation !== session) return;
      setState("Not connected");
      showError(error.message);
      $("connect").disabled = false;
    }
  }

  function disconnect() {
    // Il watchdog firmware rilascia un eventuale touch rimasto pendente.
    session++;
    connected = false;
    previousFrame = null;
    queue = [];
    pointer = null;
    clearInterval(keepAlive);
    clearTimeout(timer);
    setReady(false);
    $("connect").disabled = false;
    $("disconnect").disabled = true;
    $("refreshNow").disabled = true;
    $("host").disabled = false;
    document.body.dataset.connected = "false";
    setState("Disconnected");
  }

  function enqueue(point, pressed) {
    const sample = { x: point.x, y: point.y, pressed, view };
    const last = queue[queue.length - 1];
    // Si accorpano solo move consecutivi; down/up conservano il loro ordine.
    if (pressed && last?.pressed && queue.length > 1) queue[queue.length - 1] = sample;
    else queue.push(sample);
    schedule();
  }

  canvas.addEventListener("pointerdown", (event) => {
    if (!ready || !connected || pointer || (event.pointerType === "mouse" && event.button !== 0)) return;
    event.preventDefault();
    canvas.setPointerCapture(event.pointerId);
    pointer = { id: event.pointerId, ...protocol.coordinates(event.clientX, event.clientY, canvas.getBoundingClientRect()) };
    enqueue(pointer, true);
    keepAlive = setInterval(() => { if (pointer) enqueue(pointer, true); }, 400);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!pointer || pointer.id !== event.pointerId) return;
    const point = protocol.coordinates(event.clientX, event.clientY, canvas.getBoundingClientRect());
    if (point.x === pointer.x && point.y === pointer.y) return;
    pointer = { id: event.pointerId, ...point };
    enqueue(point, true);
  });
  function release(event) {
    if (!pointer || (event?.pointerId !== undefined && event.pointerId !== pointer.id)) return;
    enqueue(pointer, false);
    pointer = null;
    clearInterval(keepAlive);
    frameDue = true;
  }
  canvas.addEventListener("pointerup", release);
  canvas.addEventListener("pointercancel", release);
  canvas.addEventListener("lostpointercapture", release);
  window.addEventListener("blur", () => release());
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { release(); clearTimeout(timer); if (queue.length) schedule(); }
    else if (connected) { frameDue = true; schedule(); }
  });
  $("connectionForm").addEventListener("submit", connect);
  $("disconnect").addEventListener("click", disconnect);
  $("refreshNow").addEventListener("click", () => { frameDue = true; schedule(); });
  $("refresh").addEventListener("change", () => schedule());
})();
